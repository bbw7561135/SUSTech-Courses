--
-- Query contributed by 甘国豪 (GAN Guohao)
--
select *
from information_schema.columns

create table fix(table_catalog    varchar(30) not null);
                 table_schema varchar(30) not null);
                 table_name  varchar(30),
                 column_name     varchar(30) not null);
